<?php
/**
 * BookStore Theme Options
 */
class BookStore_Themeoptions_Helper_Data extends Mage_Core_Helper_Abstract
{
		
}
