<?php
/**
 * BookStore Social Widget
 */
class BookStore_SocialWidget_Helper_Data extends Mage_Core_Helper_Abstract
{
}
